# SGI 2023/2024 - TP1

## Group T02G01

| Name             | Number    | E-Mail             |
| ---------------- | --------- | ------------------ |
| Pedro Jorge da Rocha Balazeiro         | 202005097 | up202005097@up.pt                |
| Rúben Costa Viana        | 202005108 | up202005108@up.pt                |


----
## Project information
- Scene
  - In our interactive graphics systems project, we have created a room with various elements. On one wall, there are shelves, a fireplace with a carocha (a type of car) mounted above it. On another wall, we've placed a window that provides a view of a pool, and in the corner, there's a Snorlax character. On a different wall, there are three picture frames featuring images of ourselves. In the center frame, we've placed a picture of Cristiano Ronaldo, the famous footballer, and in the opposite corner, there's a vase with a flower. Yet another wall features sound columns and a TV where we can watch "Preço Certo," a TV show. In the center of the room, there's a table surrounded by eight chairs. On the table, you'll find a cake with a lit candle, a journal as per the request, and a spring. To capture all of this, we've set up a camera with the various objects as targets, and we've implemented shadows as requested. We've made every effort to adhere to all the specified requirements, and this is the ultimate outcome or final result of our work.

![scene](./screenshot/scene.png)

----
## Issues/Problems

- All items were implemented without any problems.
