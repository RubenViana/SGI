# SGI 2023/2024 - TP3

## Group: T02G01

| Name             | Number    | E-Mail             |
| ---------------- | --------- | ------------------ |
| Pedro Balazeiro        | 202005097 | up202005097@fe.up.pt               |
| Rúben Viana         | 202005108 | up202005108@fe.up.pt                |

----
## Project information

- Collisions are very precise
- movement is smooth 

### Keyboard

#### Game State

- 'w' drive
- 's' reverse
- 'a' steer left
- 'd' steer right
- 'p' for pause
- 'c' for toggle between first person view and third person view

#### Pause State

- 'p' for unpause
----
## Issues/Problems

- some problems with applying the shaders to the obstacles
